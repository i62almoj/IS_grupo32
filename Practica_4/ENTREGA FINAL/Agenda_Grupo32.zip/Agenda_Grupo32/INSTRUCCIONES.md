**1. Para iniciar la aplicación:**

* ./MenuPrincipal

**2. Datos:**

Coordinadores
___

* ID: **1** Contraseña: **David**
* ID: **2** Contraseña: **Antonio**

Ayudantes
___

* ID: **3** Contraseña: **Irene**

*Si se desea, también pueden añadirse más profesores:*

* *./GestionProfesores*
