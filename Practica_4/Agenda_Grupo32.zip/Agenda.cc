#include "Agenda.h"

Agenda::void Anadir(Agenda Alu)
{
	Agenda aux; 
	cout<<"Introduzca el DNI del alumno: ";
	cin>>aux.getDNI();
	cout<<"Introduzca el nombre del alumno: ";
	cin>>aux.getNombre();
	cout<<"Introduzca los apellidos del alumno: ";
	cin>>aux.getApellidos();
	cout<<"Introduzca el email del alumno: ";
	cin>>aux.getEmail();
	cout<<"Introduzca la dirección del alumno: ";
	cin>>aux.getDireccion();
	cout<<"Introduzca el telefono del alumno: ";
	cin>>aux.getTelefono();
	cout<<"Introduzca curso más alto matriculado del alumno: ";
	cin>>aux.getCursoAlto();
	cout<<"Introduzca el grupo del alumno: ";
	cin>>aux.getGrupo();
	cout<<"Introduzca si es lider o no el  alumno: ";
	cin>>aux.getLider();
	cout<<"Introduzca la nota del  alumno: ";
	cin>>aux.getNota();

	(*Alu)=aux; 
}