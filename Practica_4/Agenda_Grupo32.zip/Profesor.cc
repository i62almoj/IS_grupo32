#include "Profesor.h"

/*Profesor::Profesor(string ID, int Rol, Agenda Ptr_Agenda)
{
	ID_=ID;
	Rol_=Rol;
	Ptr_Agenda_=Ptr_Agenda;
}
*/
